const constants = require('../constants');

exports.CONNECTION_STRING = `mongodb://localhost:27017/${constants.DATABASE_NAME}`;
exports.PORT = 3000;