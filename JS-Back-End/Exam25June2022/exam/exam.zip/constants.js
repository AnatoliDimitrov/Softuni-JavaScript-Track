exports.DATABASE_NAME = 'cryptoTrade';
exports.SECRET = 'cryptoTrade';
exports.COOKIE_NAME = 'usersession';
exports.SALT_ROUNDS = 10;